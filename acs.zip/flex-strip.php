<div class="d-flex social-strip" style="background-color: #000;" >
  <ul class="pl-0">
      <li class="mr-2"><a href="tel:+91-7566075707">Call Us: +7566075707</a></li>
      <li><a href="https://www.youtube.com/channel/UCIkuRmEBKc2s725Oke5gwQw" target="_blank"><i class="fab fa-youtube mr-3" id="icon-font"></i></a></li>
      <li><a href="https://www.facebook.com/Aarconsnmh/" target="_blank"><i class="fab fa-facebook mr-3" id="icon-font"></i> </a></li>
      <li><a href="https://twitter.com/at_aarcons"><i class="fab fa-twitter mr-3" id="icon-font"></i> </a></li>
      <li><a href="https://www.linkedin.com/in/aarcon-nmh-ab45221a5/"><i class="fab fa-linkedin mr-3 " id="icon-font"></i></a></li> 
  </ul>   
</div>