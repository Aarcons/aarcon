<?php

if (isset($_POST['cerptgc1'])) {
    echo "ok";
}
?>