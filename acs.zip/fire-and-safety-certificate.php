<!DOCTYPE html>
<html>
<head>
	<title>Fire And Safety Certificate</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=yes">
	<meta name="description" content="">
	<meta name="keywords" content="">
	<link rel="stylesheet" type="text/css" href="css/hover.css">
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<link rel="stylesheet" href="css/social-share.css">
	<link rel="stylesheet" type="text/css" href="lib/bootstrap-4.4.1/css/bootstrap.min.css">
  	<link rel="stylesheet" type="text/css" href="lib/fontawesome/css/all.min.css">
  	<link rel="stylesheet" type="text/css" href="lib/animate-master/animate.min.css">
	<script src="lib/jquery-3.4.1/jquery-3.4.1.min.js"></script>
  	<script src="lib/waypoints-master/lib/jquery.waypoints.min.js"></script>
  	<link rel="stylesheet" href="css/main.css">
</head>
<body>
	<?php include 'flex-strip.php' ?>
  	<?php include 'new-nav.php' ?>
	<section id="page-hero">
		<div class="container-fluid">
			<div class="row">
				<h2>Fire and Safety Certificate</h2>
				<div class="overlay-services">
				</div>
			</div>
		</div>
	</section>
	</div>	
	<section id="inst-container">
	<div class="container mb-3">
		<div class="row">
			<div class="col-md-9 mt-5 main-img-section">
				<div class="img-section">
					<h3>Fire and Safety Certificate</h3>
					<p>As per the norms set up Department of School Education and Literacy, Ministry of Human Resources Development, Govt. of India and National School Safety Guideline, 2017, it is mandatory for all schools to abide by the fire and safety norms in the building. Now, every affiliating body has made it essential for the school to obtain a Fire and Safety NOC, before starting a new institute.</p>
					<p>A fire safety policy is an essential component of a building during its usage. The government has endorsed certain building codes for different kinds of fires. Fire safety means creating an infrastructure, which will reduce the danger of fire and in an unfortunate case of fire, control the spread of the fire. Fire safety includes utilizing construction material which is fire-resistant, adopting safe work practices, use of fireproof protective clothing and proper training for fire safety. It also includes electrical codes to prevent electrical hazards and to protect fire from electrical faults.</p>
					<p>Fire safety includes local building codes, clearly marking the exit gates, stair cases and installing fire extinguishers at prominent and easily accessible locations, creating fire exits in case of emergency and always keeping the passage clear. Fire safety is assessed on the basis of design of the building, presence of inflammable and risky material, need for fire alarm system, availability of fire extinguishers and hydrants and taking the training and fire drills in co-ordination with the local fire department.</p>
					<h3>How can we help?</h3>
					<p>We at <b>Aarcons</b>, will help you in the complete process of obtaining the Fire and Safety Certificate. We work with you in application process, arranging the required documents and liasoning with the concerned authorities to get the certificate.</p>
				</div>
				<div class="container pl-0 rel-article">
					<h3>Relevant Articles</h3>
					<div class="row">
						<div class="col-md-4 img-article">
							<div>
								<img src="images/rel-article/affiliation-inspection.png">
							</div>
							<div>
								<a href="#">Affiliation Inspection Support</a>
							</div>
						</div>
						<div class="col-md-4 img-article">
							<div>
								<img src="images/rel-article/turnkey-project.png">
							</div>
							<div>
								<a href="turnkey-project.php">Institutional Turnkey Project Consultation</a>
							</div>
						</div>
						<div class="col-md-4 img-article">
							<div>
								<img src="images/rel-article/staff-training.png">
							</div>
							<div>
								<a href="staff-training.php">Staff Training Seminar Workshop</a>
							</div>
						</div>
					</div>
				</div>
				
			</div>
			<?php include 'article-sidebar.php' ?>
		</div>
	</div>
	</section>
		<div class="container-fluid sticky-contact" id="desktop-sticky-contact">
			<div class="items">
				<div class="whatsapp-icon">
					<a href="//api.whatsapp.com/send?phone=917566075707&text=I_am_interested_in_fire_and_safety_certificate" title="Share on whatsapp"><img src="images/whatsapp-icon.png"></a>
				</div>
				<div class="contact-us-sticky">
					<img src="images/contact-us-2.png">
				</div>
				<a href="tel:+917566075707" class="phone-icon"><img src="images/phone-icon.png"></a>
			</div>	
		</div>
	<section id="mobile-sticky-contact">
		<img src="images/technical-support.svg" data-toggle="collapse" href="#collapseExample" class="support-image">
		<div class="collapse" id="collapseExample">
		  <div class="container-fluid sticky-contact">
		    <div class="items">
		      <div class="whatsapp-icon animated slideInLeft delay-0.8s">
		        <a href="//api.whatsapp.com/send?phone=917566075707&text=I_am_interested_in_Opening_of_New_Schools" title="Share on whatsapp"><img src="images/whatsapp-icon.png"></a>
		      </div>
		      <div class="animated slideInLeft">
		      	<a href="tel:+917566075707" class="phone-icon"><img src="images/phone-icon.png"></a>
		      </div>
		    </div>  
		  </div>    
		</div>
	</section>
	<?php include 'big-footer.php' ?>
  <a href="#" class="scrollToTop"><i class="fas fa-arrow-circle-up"></i></a>
<script src="js/script.js"></script>
<script src="lib/wow/wow.min.js"></script>
<script src="lib/popperjs-1.16.0/javascript/popper.min.js"></script>
<script src="lib/bootstrap-4.4.1/js/bootstrap.min.js"></script>
<script type="text/javascript">
	new WOW().init();
</script>
<script type="text/javascript">
  $(document).ready(function() {

    // show/hide button
    $(window).scroll(function() {

      // body...
      if ($(this).scrollTop() > 200) {
        $(".scrollToTop").fadeIn();
      }
      else{
        $(".scrollToTop").fadeOut();
      }
    });

      //smooth scroll
      $(".scrollToTop").click(function() {

        // body...
        $("html,body").animate({scrollTop: 0}, 2000)
      })
  });
</script>
</body>
</html>