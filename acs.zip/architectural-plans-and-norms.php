<!DOCTYPE html>
<html>
<head>
	<title>Architectural Plans and Norms</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=yes">
	<meta name="description" content="">
	<meta name="keywords" content="">
	<link rel="stylesheet" type="text/css" href="css/hover.css">
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<link rel="stylesheet" href="css/social-share.css">
	<link rel="stylesheet" type="text/css" href="lib/bootstrap-4.4.1/css/bootstrap.min.css">
  	<link rel="stylesheet" type="text/css" href="lib/fontawesome/css/all.min.css">
  	<link rel="stylesheet" type="text/css" href="lib/animate-master/animate.min.css">
	<script src="lib/jquery-3.4.1/jquery-3.4.1.min.js"></script>
  	<script src="lib/waypoints-master/lib/jquery.waypoints.min.js"></script>
  	<link rel="stylesheet" href="css/main.css">
</head>
<body>
	<?php include 'flex-strip.php' ?>	
  	<?php include 'new-nav.php' ?>
	<section id="page-hero">
		<div class="container-fluid">
			<div class="row">
				<h2>Architectural Plans and Norms</h2>
				<div class="overlay-services">
				</div>
			</div>
		</div>
	</section>
	</div>	
	<section id="inst-container">
	<div class="container mb-3">
		<div class="row">
			<div class="col-md-9 mt-5 main-img-section">
				<div class="img-section">
					<h3>Architectural Plans and Norms</h3>
					<p>Architectural plan is a design and planning, which has to be made before construction of a building. This plan contains architectural drawings, specifications of the design, calculations, time planning of the building process, and other documentation, which are required for the approval from the concerned authorities.</p>
					<p>A typical architectural plan contains the following things:</p>
					<ul>
						<li>Graphic description of the proposed building. This includes the sketches, drawings and details.</li>
						<li>Architectural drawing, which helps the person get an idea, how will the building look like, once it is ready. It also helps the building contractor to convert that drawing into reality.</li>
						<li>The floor plan, which shows the relationships between rooms, spaces, common areas and other physical features at one level of a structure. It also includes details of various fixtures and fittings like electrical connections etc.</li>
						<li>Scale drawing of the building.</li>
					</ul>
					<h3>How can we help?</h3>
					<p>At <b>Aarcons</b>, we have a team of experienced architects, who are the best in the country. Once you tie-up with us, our team will sit down with you to understand your requirements. Then we combine your requirements and the prescribed norms to come up with a design, which looks beautiful, fulfills your requirements and also fits in the prescribed norms.</p>
				</div>
				<div class="container pl-0 rel-article">
					<h3>Relevant Articles</h3>
					<div class="row">
						<div class="col-md-4 img-article">
							<div>
								<img src="images/rel-article/detailed-project-report.png">
							</div>
							<div>
								<a href="detailed-project-reports.php">Detailed Project Reports</a>
							</div>
						</div>
						<div class="col-md-4 img-article">
							<div>
								<img src="images/rel-article/fire-safety.png">
							</div>
							<div>
								<a href="fire-and-safety-certificate.php">Fire and Safety Certificate</a>
							</div>
						</div>
						<div class="col-md-4 img-article">
							<div>
								<img src="images/rel-article/turnkey-project.png">
							</div>
							<div>
								<a href="turnkey-project.php">Institutional Turnkey Project Consultation</a>
							</div>
						</div>
					</div>
				</div>
				
			</div>
			<?php include 'article-sidebar.php' ?>
		</div>
	</div>
	</section>
		<div class="container-fluid sticky-contact" id="desktop-sticky-contact">
			<div class="items">
				<div class="whatsapp-icon">
					<a href="//api.whatsapp.com/send?phone=917566075707&text=I_am_interested_in_architectural_plans_and_norms" title="Share on whatsapp"><img src="images/whatsapp-icon.png"></a>
				</div>
				<div class="contact-us-sticky">
					<img src="images/contact-us-2.png">
				</div>
				<a href="tel:+917566075707" class="phone-icon"><img src="images/phone-icon.png"></a>
			</div>	
		</div>
	<section id="mobile-sticky-contact">
		<img src="images/technical-support.svg" data-toggle="collapse" href="#collapseExample" class="support-image">
		<div class="collapse" id="collapseExample">
		  <div class="container-fluid sticky-contact">
		    <div class="items">
		      <div class="whatsapp-icon animated slideInLeft delay-0.8s">
		        <a href="//api.whatsapp.com/send?phone=917566075707&text=I_am_interested_in_architectural_plans_and_norms" title="Share on whatsapp"><img src="images/whatsapp-icon.png"></a>
		      </div>
		      <div class="animated slideInLeft">
		      	<a href="tel:+917566075707" class="phone-icon"><img src="images/phone-icon.png"></a>
		      </div>
		    </div>  
		  </div>    
		</div>
	</section>
	<?php include 'big-footer.php' ?>
  <a href="#" class="scrollToTop"><i class="fas fa-arrow-circle-up"></i></a>
<script src="js/script.js"></script>
<script src="lib/wow/wow.min.js"></script>
<script src="lib/popperjs-1.16.0/javascript/popper.min.js"></script>
<script src="lib/bootstrap-4.4.1/js/bootstrap.min.js"></script>
<script type="text/javascript">
	new WOW().init();
</script>
<script type="text/javascript">
  $(document).ready(function() {

    // show/hide button
    $(window).scroll(function() {

      // body...
      if ($(this).scrollTop() > 200) {
        $(".scrollToTop").fadeIn();
      }
      else{
        $(".scrollToTop").fadeOut();
      }
    });

      //smooth scroll
      $(".scrollToTop").click(function() {

        // body...
        $("html,body").animate({scrollTop: 0}, 2000)
      })
  });
</script>
</body>
</html>