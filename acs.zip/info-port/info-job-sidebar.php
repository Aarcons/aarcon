<div class="col-md-3 text-center mt-5 mt-md-0 pr-md-0 pr-lg-3" id="jb-det-sidebar">
    <h4 class="text-center side-head">Top Govt. Jobs</h4>
    <div class="container-fluid det-container">
        <div class="row">
            <div class="col-12 text-center">
                <a href="#">Job Link</a>
            </div>
        </div>
        <div class="row">
            <div class="col-12 text-center">
                <a href="#">Job Link</a>
            </div>
        </div>
        <div class="row">
            <div class="col-12 text-center">
                <a href="#">Job Link</a>
            </div>
        </div>
        <div class="row">
            <div class="col-12 text-center">
                <a href="#">Job Link</a>
            </div>
        </div>
        <div class="row">
            <div class="col-12 text-center">
                <a href="#">Job Link</a>
            </div>
        </div>
        <div class="row">
            <div class="col-12 text-center">
                <a href="#">Job Link</a>
            </div>
        </div>
        <div class="row">
            <div class="col-12 text-center">
                <a href="#">Job Link</a>
            </div>
        </div>
        <div class="row">
            <div class="col-12 text-center">
                <a href="#">Job Link</a>
            </div>
        </div>
        <div class="row">
            <div class="col-12 text-center">
                <a href="#">Job Link</a>
            </div>
        </div>
        <div class="row">
            <div class="col-12 text-center">
                <a href="#">Job Link</a>
            </div>
        </div>
        <div class="row">
            <div class="col-12 text-center">
                <a href="#">Job Link</a>
            </div>
        </div>
        <div class="row">
            <div class="col-12 text-center">
                <a href="#">Job Link</a>
            </div>
        </div>
        <div class="row">
            <div class="col-12 text-center">
                <a href="#">Job Link</a>
            </div>
        </div>
        <div class="row">
            <div class="col-12 text-center">
                <a href="#">Job Link</a>
            </div>
        </div>
        <div class="row">
            <div class="col-12 text-center">
                <a href="#">Job Link</a>
            </div>
        </div>
        
    </div>
    <h4 class="text-center side-head mt-4">Quick Links</h4>
    <div class="container-fluid det-container quick-cont">
        <div class="row">
            <div class="col-12 text-center">
                <a href="information-portal.php">Information Home</a>
            </div>
        </div>
    </div>
</div>