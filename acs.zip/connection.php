<?php
$servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "acsdb";
  $connection = new mysqli($servername, $username, $password, $dbname);
?>